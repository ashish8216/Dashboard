import Html2Pdf from './html2pdf';

export default Html2Pdf;
